﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataTable1
{
    public partial class DataTableForm : Form
    {
        public DataTableForm()
        {
            InitializeComponent();
        }

        private void DataTableForm_Load(object sender, EventArgs e)
        {
            //Create Table
            DataSet data = new DataSet();
            DataTable table = new DataTable("Employee");

            //Table Column
            table.Columns.Add("Id", typeof(int));
            table.Columns.Add("Name");
            table.Columns.Add("Designation");
            table.Rows.Add(1, "PRIYA", "Fresher");
            table.Rows.Add(2, "KRUSHNA", "Internship");

            //Table Data Store
            data.Tables.Add(table);
            dataGridView1.DataSource = data.Tables[0];   //...=data.Tables["Employee"]

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }



    }
}
