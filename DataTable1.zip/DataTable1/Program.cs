﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataTable1
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
           // Application.Run(new DataTableForm()); // This must match your form name

            Application.Run(new Form1());
            // Application.Run(new ForeachDataTable());

            //Console.ReadKey();
        }
    }
}
