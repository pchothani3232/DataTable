﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DataTable1
{
    class DataTableConsoleClass1
    {
        public static void Main(string[] args)
        {
            DataTable  emp = new DataTable(); //Creating an object of class
            emp.Columns.Add("Id");
            emp.Columns.Add("Name");
            emp.Columns.Add("Salary");
            Console.WriteLine("Enter ID, Name and Salary seprated by Comma");

            for(int i=0;i<5;i++)
            {
                DataRow row = emp.NewRow();
                string data = Console.ReadLine();


                string[] values = data.Split(',');

                row["ID"] = Convert.ToInt32(values[0]);
                row["Name"] = values[1];
                row["Salary"] = Convert.ToInt32(values[2]);

                emp.Rows.Add(row);

            }
            Console.WriteLine();
            Console.WriteLine("Employee table retrived");
            Console.WriteLine();

            foreach (DataRow R in emp.Rows)
            {
                //Console.WriteLine(R["ID"]+""+R["Name"]+""+R["Salary"]);
                foreach (DataColumn C in emp.Columns)
                    Console.Write(R[C] + " ");

                Console.WriteLine();               
            }
            Console.ReadKey();
        }
    }
}
