﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataTable1
{
    public partial class ForeachDataTable : Form
    {
        public ForeachDataTable()
        {
            InitializeComponent();
        }

        private void ForeachDataTable_Load(object sender, EventArgs e)
        {

        }
    }
}
